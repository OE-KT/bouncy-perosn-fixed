extends CharacterBody2D


const SPEED = 1000.0
const JUMP_VELOCITY = -1200.0
const DIVE_SPEED = 2200.0
var currentJumpSpeed = JUMP_VELOCITY
var timeSinceGroundHit = 0
var currentSpeed = SPEED
func _physics_process(delta: float) -> void:
	# Add the gravity.
	
	timeSinceGroundHit += delta
	if not is_on_floor():
		velocity += (get_gravity() * timeSinceGroundHit) * delta
		timeSinceGroundHit += delta

	
	# Handle jump.
	if is_on_floor():
		
		
		velocity.y = currentJumpSpeed
		timeSinceGroundHit = 0
		currentJumpSpeed = JUMP_VELOCITY
	if(Input.is_action_just_pressed("dive")):
		velocity.y = DIVE_SPEED
		currentJumpSpeed = JUMP_VELOCITY * 1.4
	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("left", "right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()
